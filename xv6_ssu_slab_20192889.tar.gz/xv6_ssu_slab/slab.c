#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "spinlock.h"
#include "slab.h"
#include <stddef.h>

struct {
	struct spinlock lock;
	struct slab slab[NSLAB];
} stable;

static int size_of_slab[NSLAB] = {8, 16, 32, 64, 128, 256, 512, 1024, 2048};


void slabinit(){
 	initlock(&stable.lock, "slab");

  	for (int i = 0; i < NSLAB; i++) {
    	struct slab *s = &stable.slab[i];
    	s->size = size_of_slab[i];
    	s->num_pages = 1;
    	s->num_free_objects = PGSIZE / s->size;
    	s->num_used_objects = 0;
    	s->num_objects_per_page = PGSIZE / s->size;

    	s->bitmap = kalloc(); // allocate 1 page
    	if (s->bitmap == 0) {
    		panic("slabinit: failed to allocate memory for bitmap");
		}
		// init for bitmap
		for (int j = 0; j < s->num_objects_per_page; j++)
      		s->bitmap[j] = 0;

		s->page[0] = kalloc();
		if (s->page[0] == 0)
			panic("slabinit: failed to allocate memory for first page");
	}
}

char *kmalloc(int size){
	if (size <= 0 || size > 2048)
		panic("kmalloc: invaild size");

	acquire(&stable.lock);

	struct slab *s = NULL;

	// 맞는 크기의 slab cache 찾기!
	for (int i = 0; i < NSLAB; i++) {
    	if (size <= size_of_slab[i]) {
      		s = &stable.slab[i];
      		break;
    	}
  	}

	// if free_objects is 0, allocate additinal page!
	if (s == NULL || s->num_free_objects == 0) {
		if (s == NULL || s->num_pages >= MAX_PAGES_PER_SLAB) {
      		release(&stable.lock);
     	 	return NULL;
    	}
		if (s->size == 8 && (s->num_pages * s->num_objects_per_page) >= 32768){
			release(&stable.lock);
			return NULL;
		}
		// allocate new page for slab
		char *new_page = kalloc();
		if (new_page == 0) {
    		release(&stable.lock);
    		panic("kmalloc: failed to allocate page");
		}

		// update slab info
		int new_page_idx = s->num_pages;
    	s->page[new_page_idx] = new_page;
    	s->num_pages++;
    	s->num_free_objects += (PGSIZE / s->size);
		
		//set bitmap
		for (int j = new_page_idx * s->num_objects_per_page; j < s->num_pages * s->num_objects_per_page; j++)
      		s->bitmap[j] = 0;
	}

  	int bitmap_idx = -1;

  	for (int i = 0; i < 32768; i++) {
    	if (s->bitmap[i] != 1) {
      		bitmap_idx = i;
          	break;
      	}
	}

  	if (bitmap_idx == -1) {
    	release(&stable.lock);
    	panic("kmalloc: failed to allocate object");
  	}

  	// Set the corresponding bit to indicate object allocation
  	s->bitmap[bitmap_idx] = 1;
  	s->num_free_objects--;
	s->num_used_objects++;
	int page_idx = bitmap_idx / s->num_objects_per_page;
	int page_bit_idx = bitmap_idx % s->num_objects_per_page; 
	char *obj = s->page[page_idx] + page_bit_idx * s->size;

	release(&stable.lock);
	return obj;
}

void kmfree(char *addr, int size){
	if (addr == NULL || size <= 0) {
    	panic("kmfree: invalid arguments");
 	}

  	acquire(&stable.lock);

  	struct slab *s = NULL;

  	// Find the appropriate slab cache based on size
  	for (int i = 0; i < NSLAB; i++) {
    	if (size <= size_of_slab[i]) {
      		s = &stable.slab[i];
      		break;
    	}
  	}
	
	// can't find appropriate size..
  	if (s == NULL) {
    	release(&stable.lock);
    	panic("kmfree: invalid size");
  	}

	int page_idx = -1;
	for (int i = 0 ; i < s->num_pages ; i++){
		if (addr - s->page[i] >= 0){
			page_idx = i;
			break;
		}
	}

	if (page_idx == -1) {
    	release(&stable.lock);
    	panic("kfree: failed to free");
  	}

	int bitmap_idx = page_idx * s->num_objects_per_page + (addr - s->page[page_idx])/s->size;
	s->bitmap[bitmap_idx] = 0;
  	s->num_free_objects++;
	s->num_used_objects--;
  	release(&stable.lock);
}

void slabdump(){
	cprintf("__slabdump__\n");

	struct slab *s;

	cprintf("size\tnum_pages\tused_objects\tfree_objects\n");

	for(s = stable.slab; s < &stable.slab[NSLAB]; s++){
		cprintf("%d\t%d\t\t%d\t\t%d\n", 
			s->size, s->num_pages, s->num_used_objects, s->num_free_objects);
	}
}

int numobj_slab(int slabid)
{
	return stable.slab[slabid].num_used_objects;
}
